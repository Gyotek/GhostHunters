#ifndef UI_CONSTANTS_H
#define UI_CONSTANTS_H

static const float k_background_alpha = 0.65f;

#define UI_ARRAYSIZE(_ARR)      ((int)(sizeof(_ARR)/sizeof(*_ARR)))

#endif // UI_CONSTANTS_H