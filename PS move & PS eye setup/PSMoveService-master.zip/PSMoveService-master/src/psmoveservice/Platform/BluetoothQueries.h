#ifndef BLUETOOTH_QUERIES_H
#define BLUETOOTH_QUERIES_H
// -- includes -----
#include <string>

// -- interface -----
bool bluetooth_get_host_address(std::string &out_address);

#endif // BLUETOOTH_QUERIES_H
