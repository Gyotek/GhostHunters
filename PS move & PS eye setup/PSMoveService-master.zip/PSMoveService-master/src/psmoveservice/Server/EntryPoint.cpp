//-- includes -----
#include "PSMoveService.h"

//-- entry point -----
int main(int argc, char *argv[])
{
    PSMoveService app;

    return app.exec(argc, argv);
}
